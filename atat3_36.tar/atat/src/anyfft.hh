#include <complex.h>
#include "misc.h"

void fftnd(Complex *data, int ndim, int *dims, int isign);
