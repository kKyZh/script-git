#include "misc.h"

Real invnormalcdf(Real p);
Real normal01(void);
